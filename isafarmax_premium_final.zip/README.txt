ISAFARMAX - PÁGINA WEB PREMIUM

INSTRUCCIONES PARA PUBLICAR:
1. Descomprima este archivo ZIP.
2. Ingrese al administrador de archivos de Hostinger, GoDaddy o su hosting.
3. Suba todos los archivos y carpetas dentro de public_html.
4. El archivo principal es index.html.
5. El botón de WhatsApp ya está configurado con el número 3104585960.
6. Se eliminó la sección de proyectos ejecutados.

Para cambiar correo o textos, edite index.html.
