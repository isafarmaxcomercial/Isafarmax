const btn=document.getElementById('menuBtn');const menu=document.getElementById('menu');btn?.addEventListener('click',()=>menu.classList.toggle('open'));
const obs=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('show')})},{threshold:.14});document.querySelectorAll('.reveal').forEach(el=>obs.observe(el));
